﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youtube.Math.functions;

namespace TesteDLL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Sigmoid.Calculate(10.0));
        }
    }
}
