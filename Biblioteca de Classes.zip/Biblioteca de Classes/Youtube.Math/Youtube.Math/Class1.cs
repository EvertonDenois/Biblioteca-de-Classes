﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youtube.Math
{
    namespace functions
    {
        /// <summary>
        /// Classe que calcula a função Sigmoid
        /// </summary>
        public class Sigmoid
        {
            /// <summary>
            /// Método que retornar a função Sigmoid de um número
            /// </summary>
            /// <param name="x"></param>
            /// <returns></returns>
            public static double Calculate(double x)
            {
                return 1.0 / (1.0 + System.Math.Exp(-x));
            }
        }
    }
}
